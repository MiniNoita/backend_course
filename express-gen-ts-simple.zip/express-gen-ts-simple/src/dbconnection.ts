/* eslint-disable no-process-env */
/* eslint-disable no-console */ 
import 'dotenv/config';
import { connect } from 'mongoose';

export const dbConnect = async () => {
 
  console.log("URL-check:", process.env.MONGODB_URL);
  try {
    
    const mongoUrl = process.env.MONGODB_URL;

    if (!mongoUrl) {
      throw new Error('MONGODB_URL missing!');
    }
    await connect(mongoUrl || '');
    
    console.log('MongoDb connected');
  } catch (error) {
    console.log('MongoDb connection error:', error);
    process.exit(1);
  }
};
