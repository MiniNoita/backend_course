import { Request, Response } from 'express';
//import { IPlainObject } from 'jet-validators';
type IPlainObject = Record<string, unknown>;

/******************************************************************************
                                Types
******************************************************************************/

type UrlParams = Record<string, string>;

export type Req = Request<UrlParams, void, IPlainObject>;
export type Res = Response;
