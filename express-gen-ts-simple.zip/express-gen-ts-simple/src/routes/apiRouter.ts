import { Router } from 'express';

import Paths from '@src/common/constants/Paths';

import StudentRoutes from './StudentRoutes';

/******************************************************************************
                                Setup
******************************************************************************/

const apiRouter = Router();

// ----------------------- Add studentRouter --------------------------------- //

const studentRouter = Router();

studentRouter.get(Paths.Students.Get, StudentRoutes.findAll);
studentRouter.post(Paths.Students.Add, StudentRoutes.addStudent);

apiRouter.use(Paths.Students._, studentRouter);

/******************************************************************************
                                Export
******************************************************************************/

export default apiRouter;
