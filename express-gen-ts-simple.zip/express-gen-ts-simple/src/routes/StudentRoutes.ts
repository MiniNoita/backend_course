import HttpStatusCodes from '@src/common/constants/HttpStatusCodes';
import { IStudent } from '@src/models/IStudent';
import StudentService from '@src/services/StudentService';

import { Req, Res } from './common/express-types';

/******************************************************************************
                                Functions
******************************************************************************/

/**
 * Get all students.
 * Route path is defined in src/common/constants/Paths.ts
 *
 * @route GET /api/students/all
 */
async function findAll(_: Req, res: Res) {
  const students = await StudentService.findAll();
  // eslint-disable-next-line no-console
  console.log(students);
  res.status(HttpStatusCodes.OK).json({ students });
}
/**
 * Post a student.
 * Route path is defined in src/common/constants/Paths.ts
 *
 * @route POST /api/students/add
 */
async function addStudent(req: Req, res: Res) {
  const newStudent: IStudent = req.body as unknown as IStudent;
  await StudentService.addStudent(newStudent);
  res
    .status(HttpStatusCodes.CREATED)
    .json({ message: 'Student added successfully' });
}

/******************************************************************************
                                Export default
******************************************************************************/

export default {
  addStudent,
  findAll,
} as const;
