/* eslint-disable no-console */
import Student from '../models/Student';
import { IStudent } from '../models/IStudent';

/******************************************************************************
                                Functions
******************************************************************************/

async function findAll(): Promise<IStudent[] | undefined> {
  const students = await Student.find().catch((err) => {
    console.log(err);
    return undefined;
  });
  console.log(students);
  // students-taulukko
  return students as IStudent[] | undefined;
}

async function addStudent(newstudent: IStudent): Promise<void> {
  const savedStudent = await Student.create(newstudent).catch((err) => {
    console.log(err);
  });
  console.log(`Uusi opiskelija luotu:`, savedStudent);
}

/******************************************************************************
                                Export default
******************************************************************************/

export default {
  findAll,
  addStudent,
} as const;
