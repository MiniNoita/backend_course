export interface IStudent {
  studentcode: string;
  name: string;
  email: string;
  studypoints?: number | null;
  grades: {
    course: string;
    grade: number;
  }[];
}