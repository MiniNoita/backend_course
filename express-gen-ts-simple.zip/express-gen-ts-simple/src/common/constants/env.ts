import jetEnv, { num } from 'jet-env';

/******************************************************************************
                                 Constants
******************************************************************************/

// NOTE: These need to match the names of your ".env" files
export const NodeEnvs = {
  DEV: 'development',
  PRODUCTION: 'production',
} as const;

// Type guard for NodeEnv validation
const isNodeEnv = (
  value: unknown,
): value is (typeof NodeEnvs)[keyof typeof NodeEnvs] => {
  return Object.values(NodeEnvs).includes(
    value as 'development' | 'production',
  );
};

/******************************************************************************
                                 Setup
******************************************************************************/

const EnvVars = jetEnv({
  NodeEnv: isNodeEnv,
  Port: num,
});

/******************************************************************************
                            Export default
******************************************************************************/

export default EnvVars;
