import jetPaths from 'jet-paths';

const Paths = {
  _: '/api',
  Students: {
    _: '/students',
    Get: '/all',
    Add: '/add',
    Update: '/update',
    Delete: '/delete/:id',
  },
} as const;

export const JetPaths = jetPaths(Paths);
export default Paths;
