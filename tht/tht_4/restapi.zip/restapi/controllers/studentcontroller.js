/*
Kontrolleri on olio, joka sisältää metodeja. Se tehty siksi, että
saadaan erotettua reitit ja tietokantahakujen sovelluslogiikka toisistaan.
Se on siis arkkitehtuuriratkaisu. Eli saamme aikaan järkevämmän arkkitehtuurin
kun jaamme eri asioita tekevän koodin eri tiedostoihin ja kansioihin.
*/

const Student = require('../models/Student'); // haetaan model

// Tietokannan käsittelymetodit tehdään olion sisään
const StudentController = {
  /* 1) findAll -metodi hakee kaikki opiskelijat
  Student-modelin find-metodilla */
  async findAll(req, res) {
    const students = await Student.find().catch((err) => {
      console.log(err);
    });
    // saadaan students-taulukko
    console.log(students);
    // response eli vastaus on json-muotoinen
    res.json(students);
  },
  async findById(req, res) {//Mongoose-kantaoperaatio tänne
  },
  async addStudent(req, res) {//Mongoose-kantaoperaatio tänne
  }, //jne...
};

module.exports = StudentController;

/*
students.js -reittitiedostossa kontrollerin metodia kutsutaan tällä tavalla:
 
router.get('/', StudentController.findAll);
 
jolloin kaikki opiskelijat saadaan JSON-muodossa osoitteesta http://localhost:3000/students/

*/
